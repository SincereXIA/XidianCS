alter procedure proStudentAvg(@sNo char(9),@avg numeric(6,2) output)
as
begin
	declare @sName char(20),@cName char(40)
	declare @grade smallint,@sum int,@count tinyint
	select @sum=0,@count=0
	--���塢�򿪡���ȡ�α�
	declare curGrade cursor for
		select Sname,Cname,Grade
		from Student a,Course b,SC c
		where a.Sno=c.Sno and b.Cno=c.Cno and a.Sno=@sNo
	open curGrade
	fetch curGrade into @sName, @cName, @grade
	while(@@FETCH_STATUS=0)
	begin
		--ҵ����
		set @sum=@sum+@grade
		set @count=@count+1
		fetch curGrade into @sName, @cName, @grade
	end
	close curGrade
	deallocate curGrade
	if @count>0
		select @avg=0
	else
		select @avg=@sum/@count
end
