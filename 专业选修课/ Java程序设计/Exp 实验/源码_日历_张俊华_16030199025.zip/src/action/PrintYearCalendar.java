package action;

import service.MonthCalendar;
import ui.UI;

/**
 * Created by 张俊华 on 2017/3/28.
 */
public class PrintYearCalendar {
    public static void main(int LINE){
        /**
         *控制台输入任意年份，实现m*n年历的绘制，m必须能被12整除
         *@param LINE
         *@return
         *@exception
         *@author 张俊华 16030199025
         */
        UI ui = new UI();
        int year = ui.scanYear();
        //初始化 ui 及 scaner
        StringBuffer yearCalendar[][] = new StringBuffer[12][6]; //年历数组
        for (int month = 1;month<=12;month++){
            yearCalendar[month-1] = MonthCalendar.getMonthCalender(year,month);
        } //调用getMonthCalender 给年历数组赋值
        int month = 0;
        StringBuffer head = new StringBuffer(); //年历表头
        for (int i =0;i<LINE;i++){
            head.append("\t一\t二\t三\t四\t五\t六\t日").append("\t\t");
        }//生成对应长度的表头
        for (int row = 0;row<12/LINE;row++) {
            System.out.println(head);
            for (int r = 0; r < 6; r++) {
                for (int line = 0; line < LINE; line++) {
                    System.out.print(yearCalendar[month][r]);
                    System.out.print("\t\t");
                    month++;
                } //输出每一行
                month-=LINE; //下一行月份归位
                System.out.println();
            }
            month+=LINE; //月份递进
        }
    }
}
