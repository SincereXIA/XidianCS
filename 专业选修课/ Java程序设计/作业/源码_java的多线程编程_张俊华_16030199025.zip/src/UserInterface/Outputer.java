package UserInterface;

/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 16:17.
 */
public class Outputer {
    /**
     *打印票
     *@param sellerName 售票员姓名
     *@param ticketNumber 票号
     *@author 张俊华 16030199025
     */
    public static void PrintTickets(String sellerName, int ticketNumber ,int customerIndex){
        System.out.printf("窗口%s为%d号顾客出售编号%d电影票\n",sellerName,customerIndex,ticketNumber);
    }

}
