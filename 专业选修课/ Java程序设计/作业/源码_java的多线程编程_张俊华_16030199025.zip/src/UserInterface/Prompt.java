package UserInterface;

/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 16:17.
 */
public class Prompt {
    public void ShowMenu() {
        System.out.printf("+%20s+\n", "-------------------------------------");
        System.out.printf("|\t%4s%20s\t%10s\n", "选项", "功能", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "1", "模拟售票", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "s", "系统设置", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "q", "退出系统", "|");
        System.out.printf("+%20s+\n", "-------------------------------------");

    }

    public void TipWrong() {
        System.out.println("程序出现异常!!");
    }

    public void ShowSettings() {
        System.out.printf("+%20s+\n", "--------设置--------");
        System.out.printf("|\t%4s%20s\t%10s\n", "选项", "功能", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "1", "修改售票窗口", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "2", "设定票据总数", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "3", "修改购买频率", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "q", "退出设置", "|");
        System.out.printf("+%20s+\n", "--------------------");
    }

    public void ShowConductorsSettings(){
        System.out.printf("+%20s+\n", "--------售票窗口设置--------");
        System.out.printf("|\t%4s%20s\t%10s\n", "选项", "功能", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "1", "展示售票窗口", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "2", "增加售票窗口", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "3", "删除售票窗口", "|");
        System.out.printf("|\t%4s%20s\t%10s\n", "q", "退出售票窗口设置", "|");
        System.out.printf("+%20s+\n", "--------------------");
    }

}
