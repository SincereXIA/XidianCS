package UserInterface;

import java.util.Scanner;

/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 16:17.
 */
public class Inputer {
    Scanner scanner = new Scanner(System.in);

    /**
     *从控制台获取输入选项
     *@return choise 选项
     *@author 张俊华 16030199025
     */
    public String ScanChoise() {
        String choise;
        System.out.print("请输入选项：");
        choise = this.scanner.next();
        return choise;
    }

    /**
     *从控制台获取输入速度
     *@author 张俊华 16030199025
     */
    public long ScanSpeed() {
        long speed;
        System.out.print("请输入速度：");
        speed = this.scanner.nextLong();
        return speed;
    }
    /**
     *从控制台获取输入总票数
     *@author 张俊华 16030199025
     */
    public int ScanTotalTickets() {
        int speed;
        System.out.print("请输入总票数：");
        speed = this.scanner.nextInt();
        return speed;
    }
    /**
     *从控制台获取输入名称
     *@return name 名称
     *@author 张俊华 16030199025
     */
    public String ScanName() {
        String name;
        System.out.print("请输入名称：");
        name = this.scanner.next();
        return name;
    }
    /**
     *从控制台获取输入编号
     *@author 张俊华 16030199025
     */
    public int ScanNumber() {
        int speed;
        System.out.print("请输入编号：");
        speed = this.scanner.nextInt();
        return speed;
    }
}
