/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 16:22.
 */
public class TicketsBox {
    private int ticketsNumber = 0;
    private int totalTickets;
    TicketsBox(int totalTickets){
        this.totalTickets = totalTickets;
    }
    /**
     *票箱出一张票
     *@author 张俊华 16030199025
     */
    public synchronized int PushaTicket(){
        ticketsNumber++;
        if (ticketsNumber<=totalTickets){
            return ticketsNumber;
        }else {
            return -1;
        }
    }
}
