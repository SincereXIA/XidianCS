import UserInterface.Prompt;

/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 16:13.
 */
public class Main {

    public static void main(String args[]){
        Actions actions = new Actions();
        while (actions.UserChoise());
    }
}
