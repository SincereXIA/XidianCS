import UserInterface.Outputer;

/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 16:16.
 */
public class Conductor extends Thread{
    private String name;
    private long speed;
    private TicketsBox ticketsBox;
    Conductor(String name,long speed,TicketsBox ticketsBox){
        this.name = name;
        this.speed = speed;
        this.ticketsBox = ticketsBox;
    }

    /**
     *出售一张票
     *@author 张俊华 16030199025
     */
    public void SellaTicket(int customerIndex) throws InterruptedException {
        sleep(speed);
        Outputer.PrintTickets(this.name,this.ticketsBox.PushaTicket(),customerIndex);

    }
    /**
     *自我介绍
     *@author 张俊华 16030199025
     */
    public void ShowSelf(){
        System.out.println("窗口名称："+this.name);
        System.out.println("售票速度："+this.speed);
    }
}
