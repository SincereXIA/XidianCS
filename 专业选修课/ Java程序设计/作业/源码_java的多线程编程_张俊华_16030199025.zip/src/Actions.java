import UserInterface.Inputer;
import UserInterface.Prompt;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 17:16.
 */
public class Actions extends Thread{
    private Prompt prompt = new Prompt();
    private Inputer inputer = new Inputer();
    private long buyingSpeed;
    private ArrayList<Conductor> conductors = new ArrayList<>();
    private TicketsBox ticketsBox;

    Actions(){
        System.out.println("正在进行初始化设置，程序运行需要...");
        SetTicketsBox();
        SetConductors();
        SetBuyingSpeed();
        System.out.println("初始化完成！");
    }
    /**
     * 设置
     *
     * @author 张俊华 16030199025
     */
    public boolean Sets() {
        prompt.ShowSettings();
        String choise = inputer.ScanChoise();
        switch (choise) {
            case "1":
                while (SetConductors());
                break;
            case "2":
                SetTicketsBox();
                break;
            case "3":
                SetBuyingSpeed();
                break;
            case "q":
                return false;
        }
        return true;
    }

    /**
     * 设置购买频率
     *
     * @author 张俊华 16030199025
     */
    public void SetBuyingSpeed() {
        System.out.println("当前购买速度为：" + this.buyingSpeed + "ms/位");
        this.buyingSpeed = inputer.ScanSpeed();
    }

    /**
     * 设置票箱
     *
     * @author 张俊华 16030199025
     */
    public void SetTicketsBox() {
        this.ticketsBox = new TicketsBox(inputer.ScanTotalTickets());
        System.out.println("设置成功！");
    }


    /**
     * 开始售票
     *
     * @author 张俊华 16030199025
     */
    public void StartSell() throws InterruptedException {
        for (Conductor conductor:conductors){
            conductor.start();
        }
        int index = 0;

        while (true){

            Customer customer = new Customer(++index,conductors);
            customer.start();
            Thread.sleep(buyingSpeed);
        }

    }

    public boolean UserChoise() {
        prompt.ShowMenu();
        //打印菜单
        String choise = inputer.ScanChoise();
        try {
            switch (choise) {
                case "s":
                    while (Sets());
                    break;
                case "1":
                    StartSell();
                    break;
                case "q":
                    return false;
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            prompt.TipWrong();
            ex.printStackTrace();
        }
        System.out.println("请输入任意字符继续...");
        new Scanner(System.in).next();

        return true;
    }

    /**
     * 展示售票窗口
     *
     * @author 张俊华 16030199025
     */
    public void ShowConductors() {
        for (Conductor conductor : conductors) {
            conductor.ShowSelf();
            System.out.println("");
        }

    }

    /**
     * 增加售票窗口
     *
     * @author 张俊华 16030199025
     */
    public void AddConductor() {
        while (true) {
            conductors.add(new Conductor(inputer.ScanName(), inputer.ScanSpeed(), this.ticketsBox));
            System.out.println("继续添加吗？");
            if (!inputer.ScanChoise().equals("y")) {
                break;
            }
        }
    }

    /**
     * 删除售票窗口
     * @author 张俊华 16030199025
     */
    public void DellConductor() {
        int index = inputer.ScanNumber();
        System.out.println("要删除的窗口为：");
        conductors.get(index).ShowSelf();
        System.out.println("确认删除吗?(y/n)");
        if(inputer.ScanChoise().equals("y")){
            conductors.remove(index);
        }
    }

    /**
     * 修改售票窗口设置
     * @author 张俊华 16030199025
     */
    public boolean SetConductors() {
        prompt.ShowConductorsSettings();
        String choise = inputer.ScanChoise();
        switch (choise) {
            case "1":
                ShowConductors();
                break;
            case "2":
                AddConductor();
                break;
            case "3":
                DellConductor();
                break;
            case "q":
                return false;
        }
        return true;

    }
}
