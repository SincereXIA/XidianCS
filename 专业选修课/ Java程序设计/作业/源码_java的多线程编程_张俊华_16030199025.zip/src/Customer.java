import java.util.ArrayList;
import java.util.Random;

/**
 * Created by 张俊华 on 2017/6/22.
 *
 * @author 张俊华.
 * @Time 2017/6/22 16:28.
 */
public class Customer extends Thread{
    /**
     *买一张票
     *@author 张俊华 16030199025
     */
    int index;
    ArrayList<Conductor> conductors;
    Customer(int index, ArrayList<Conductor> conductors) throws InterruptedException {
        System.out.println("迎来了第" +(index)+ "位顾客...");
        this.index=index;
        this.conductors = conductors;
    }
    public void BuyaTicket(Conductor conductor) throws InterruptedException {
        conductor.SellaTicket(index);
    }

    @Override
    public void run() {
        try {
            BuyaTicket(conductors.get(new Random().nextInt(conductors.size())));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
